package com.employeejavaangularcrud.model;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.*;


@Entity
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long empid;
	@NotBlank(message="Employee firstname is required")
	private String firstname;
	@NotBlank(message="Employee lastname is required")
	private String lastname;
	@NotBlank(message="Employee address is required")
	private String address;
	@NotNull(message="Employee salary is required")
	@DecimalMin(value="0.0",message="Salary must be greater that or equal to 0")
	private Double salary;
	
	@NotBlank(message="Employee email is required")
	@Email(message="Invalid email format")
	private String email;
	
	@NotBlank(message="Employee phone number is required")
	@Pattern(regexp="^(\\d{10})$",message="Inavlid phone number format")
	private String phone;
	

	
	public Employee(Long empid, String firstname, String lastname, String address, Double salary,
			 String email, String phone) {
			
			this.empid = empid;
			this.firstname = firstname;
			this.lastname = lastname;
			this.address = address;
			this.salary = salary;
			this.email = email;
			this.phone = phone;
		}
			public Employee() {
					
				}
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", firstname=" + firstname + ", lastname=" + lastname + ", address="
				+ address + ", salary=" + salary + ", email=" + email + ", phone=" + phone + "]";
	}
	
	public Long getEmpid() {
		return empid;
	}
	public void setEmpid(Long empid) {
		this.empid = empid;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
}
