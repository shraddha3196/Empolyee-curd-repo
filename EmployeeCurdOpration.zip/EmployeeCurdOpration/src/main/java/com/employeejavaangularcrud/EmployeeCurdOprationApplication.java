package com.employeejavaangularcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages ="com.employeejavaangularcrud.controller")
public class EmployeeCurdOprationApplication {

	public static void main(String[] args) {
	
		SpringApplication.run(EmployeeCurdOprationApplication.class, args);
	}

}
