package com.employeejavaangularcrud.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.employeejavaangularcrud.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {


}
