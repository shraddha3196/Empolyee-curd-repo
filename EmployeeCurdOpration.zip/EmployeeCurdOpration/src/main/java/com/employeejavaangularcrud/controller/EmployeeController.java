package com.employeejavaangularcrud.controller;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.employeejavaangularcrud.customException.EmployeeValidationException;
import com.employeejavaangularcrud.customException.EmpolyeeNotFoundException;
import com.employeejavaangularcrud.model.Employee;
import com.employeejavaangularcrud.repository.EmployeeRepository;
//   http://localhost:8080/api/V1/addemp     -post
//   http://localhost:8080/api/V1/employees  -all get 
//  http://localhost:8080/api/V1/employees/{id}     -get by id 
//  http://localhost:8080/api/V1/employees/{id}  -update data
//  http://localhost:8080/api/V1/employeeSal - get empolyee by salary

@RestController
@RequestMapping("/api/V1/")
@Validated
@CrossOrigin(origins ="http://localhost:4200/")
public class EmployeeController {
	
	private List<Employee>employees=new ArrayList<>();
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	//get allEmpData
	@GetMapping("/employees")
	public List<Employee> displayMesg() {
		return employeeRepository.findAll();
		
	}
	
	//get empdata by id
	@GetMapping("/employees/{id}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable Long id){
		Optional<Employee> getEmpId= employeeRepository.findById(id);
		if(getEmpId.isPresent()) {
			return new ResponseEntity<Employee>(getEmpId.get(),HttpStatus.OK);
		}else {
			return new ResponseEntity<Employee>(HttpStatus.NOT_FOUND);
		}
				
	}
	
	
	@PostMapping("/addemp")
	public  ResponseEntity<Employee> addEmployee(@Valid @RequestBody Employee emp,BindingResult bindresult) {
		if(bindresult.hasErrors()) {
			throw new EmployeeValidationException(bindresult);
		}
			employeeRepository.save(emp);
	
			return new ResponseEntity<>(emp,HttpStatus.CREATED);
	}

	
	//updateDataById
	@PutMapping("/employees/{id}")
	public ResponseEntity<Employee> updateEmployeeData(@PathVariable Long id,@Valid @RequestBody Employee employeeDetails)throws EmpolyeeNotFoundException{
	
		Employee getemp = employeeRepository.findById(id)
			        .orElseThrow(() -> new EmpolyeeNotFoundException("Employee not found for this id :: " + id));

				getemp.setFirstname(employeeDetails.getFirstname());
				getemp.setLastname(employeeDetails.getLastname());
				getemp.setAddress(employeeDetails.getAddress());
				getemp.setSalary(employeeDetails.getSalary());
				getemp.setEmail(employeeDetails.getEmail());
				getemp.setPhone(employeeDetails.getPhone());
			  Employee updatedEmployee = employeeRepository.save(getemp);
			        return ResponseEntity.ok().body(updatedEmployee);
	}
	
	//Delete empolyee by id
	@DeleteMapping("/employees/{id}")
	public String DeleteById(@PathVariable Long id) {
	Optional<Employee> delId=employeeRepository.findById(id);
		employeeRepository.deleteById(id);
		return "data deleteted succesfully !!";
		
	}
	//getSalary grater than 50000
	@GetMapping("/employeeSal")
	public List<Employee> getEmpwithSalarGreater50000() {
	return employeeRepository.findAll()
		.stream().filter(employee -> employee.getSalary()>50000)
				.sorted(Comparator.comparing(Employee::getFirstname))
				.collect(Collectors.toList());
		
	}
	
	
	
}
