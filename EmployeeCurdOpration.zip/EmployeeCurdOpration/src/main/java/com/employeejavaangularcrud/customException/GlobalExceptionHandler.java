package com.employeejavaangularcrud.customException;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.employeejavaangularcrud.model.Employee;

@ControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(EmployeeValidationException.class)
	public ResponseEntity<Employee>handleValidationException(EmployeeValidationException ex){
		BindingResult result=ex.getBindingResult();
		Map<String,String>errorMap=new HashMap<>();
		for(FieldError error:result.getFieldErrors()) {
			errorMap.put(error.getField(), error.getDefaultMessage());
		}
		return new ResponseEntity<Employee>(HttpStatus.BAD_REQUEST);
		
	}

}
