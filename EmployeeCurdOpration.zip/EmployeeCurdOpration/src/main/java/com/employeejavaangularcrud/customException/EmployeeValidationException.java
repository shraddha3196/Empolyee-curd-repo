package com.employeejavaangularcrud.customException;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;


public class EmployeeValidationException extends RuntimeException {
private BindingResult bindingResult;
	
	public EmployeeValidationException(BindingResult bindResult) {
		
	this.bindingResult=bindResult;
	}
	
	public BindingResult getBindingResult(){
		return bindingResult;
	}
	
}
