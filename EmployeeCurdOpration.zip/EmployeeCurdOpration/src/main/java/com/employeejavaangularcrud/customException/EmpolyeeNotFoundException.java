package com.employeejavaangularcrud.customException;

import com.employeejavaangularcrud.model.Employee;

public class EmpolyeeNotFoundException extends RuntimeException{

	public EmpolyeeNotFoundException (String message){
        super(message);
    }
	
	
}
